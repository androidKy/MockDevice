package com.proxy.droid;

/**
 * Description:
 * Created by Quinin on 2019-10-26.
 **/
public class ProxyConstant {
    public final static String SP_IP_PORTS = "sp_ip_ports";
    public final static String SP_CITY_LIST = "sp_city_data";
    public final static String KEY_CITY_DATA = "key_cities";
    public final static String KEY_CITY_GET_DATE = "key_city_get_date";
    public final static String KEY_IP_DATA = "key_ip_data";
    public final static String KEY_IP = "key_ip";
    public final static String KEY_CUR_PORT = "key_cur_port";
}
