package com.proxy.droid.core;

/**
 * Description:
 * Created by Quinin on 2019-10-28.
 **/
public interface ProxyStatusListener {
    void onProxyStatus(boolean status,String msg);
}
